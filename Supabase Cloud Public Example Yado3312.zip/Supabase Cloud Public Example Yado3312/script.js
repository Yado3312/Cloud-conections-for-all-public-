import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const supabaseUrl = 'https://ckvyazrrnwkikpxnxqzx.supabase.co';
const supabaseKey = 'private key'; 
const supabase = createClient(supabaseUrl, supabaseKey);

document.getElementById('form-registro').addEventListener('submit', async (event) => {
    event.preventDefault(); 

    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const correo = document.getElementById('correo-registro').value;
    const password = document.getElementById('password-registro').value;

    try {
        const { data: authData, error: authError } = await supabase.auth.signUp({
            email: correo,
            password: password,
        });
        if (authError) {
            document.getElementById('mensaje-registro').textContent = authError.message;
            document.getElementById('mensaje-registro').classList.add('error');
            return;
        }
        const { data: usuarioData, error: usuarioError } = await supabase
            .from('usuarios')
            .insert([
                {
                    id: authData.user.id,
                    nombre: nombre,
                    apellido: apellido,
                    correo: correo,
                },
            ]);

        if (usuarioError) {
            document.getElementById('mensaje-registro').textContent =
                'Error al guardar los datos del usuario.';
            document.getElementById('mensaje-registro').classList.add('error');
            return;
        }

        document.getElementById('mensaje-registro').textContent = 'Registro exitoso. Revisa tu correo para verificarlo TORTOLITO.';
        document.getElementById('mensaje-registro').classList.add('success');
    } catch (error) {
        console.error('Error inesperado:', error);
        document.getElementById('mensaje-registro').textContent = 'Ocurrió un error inesperado. Por favor, inténtalo de nuevo perra.';
        document.getElementById('mensaje-registro').classList.add('error');
    }
});

document.getElementById('form-login').addEventListener('submit', async (event) => {
    event.preventDefault();
    const correo = document.getElementById('correo-login').value;
    const password = document.getElementById('password-login').value;

    const { data, error } = await supabase.auth.signInWithPassword({
        email: correo,
        password: password,
    });

    if (error) {
        document.getElementById('mensaje-login').textContent = error.message;
        document.getElementById('mensaje-login').classList.add('error');
        return;
    }

    // Verificar si el correo está confirmado
    if (!data.user.email_confirmed_at) {
        document.getElementById('mensaje-login').textContent = 'Por favor, confirme su correo electronico pls alv';
        document.getElementById('mensaje-login').classList.add('error');
        return;
    }

    document.getElementById('mensaje-login').textContent = 'Eres el mas chingon, continua';
    document.getElementById('mensaje-login').classList.add('success');
    setTimeout(() => {
        window.location.href = '/League of leguends.html';
    }, 2000);
});

async function mostrarUsuarios() {
    const { data: usuarios, error } = await supabase
        .from('usuarios')
        .select('*');  

    if (error) {
        console.error('Error al obner los usuarios:', error);
        return;
    }

    const listaUsuarios = document.getElementById('lista-usuarios'); 
    listaUsuarios.innerHTML = '';  
    usuarios.forEach(usuario => {
        const li = document.createElement('li'); 
        li.textContent = `${usuario.nombre} ${usuario.apellido} - ${usuario.correo}`;
        listaUsuarios.appendChild(li);  
    });
}


document.addEventListener('DOMContentLoaded', mostrarUsuarios);
